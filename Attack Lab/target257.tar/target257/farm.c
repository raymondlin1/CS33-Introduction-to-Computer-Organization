/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_362(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_268(unsigned x)
{
    return x + 3347662929U;
}

unsigned getval_295()
{
    return 3347597394U;
}

void setval_398(unsigned *p)
{
    *p = 2425379047U;
}

void setval_249(unsigned *p)
{
    *p = 3284633929U;
}

unsigned addval_391(unsigned x)
{
    return x + 2421722787U;
}

void setval_384(unsigned *p)
{
    *p = 4190263334U;
}

void setval_401(unsigned *p)
{
    *p = 1343665068U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_107(unsigned x)
{
    return x + 3247493513U;
}

unsigned addval_371(unsigned x)
{
    return x + 2430634248U;
}

unsigned addval_354(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_185()
{
    return 3286272330U;
}

void setval_484(unsigned *p)
{
    *p = 2425409163U;
}

void setval_338(unsigned *p)
{
    *p = 3229926017U;
}

unsigned addval_348(unsigned x)
{
    return x + 3682914689U;
}

unsigned getval_437()
{
    return 3675836041U;
}

unsigned addval_115(unsigned x)
{
    return x + 3223900553U;
}

void setval_109(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_280()
{
    return 3469311450U;
}

unsigned addval_278(unsigned x)
{
    return x + 700564105U;
}

unsigned addval_405(unsigned x)
{
    return x + 3767077099U;
}

void setval_246(unsigned *p)
{
    *p = 3525365387U;
}

unsigned addval_315(unsigned x)
{
    return x + 3674788233U;
}

unsigned addval_454(unsigned x)
{
    return x + 3383018121U;
}

void setval_409(unsigned *p)
{
    *p = 3465102681U;
}

unsigned getval_240()
{
    return 3380924809U;
}

void setval_476(unsigned *p)
{
    *p = 3374891657U;
}

unsigned addval_441(unsigned x)
{
    return x + 3525890441U;
}

unsigned getval_273()
{
    return 3223375489U;
}

unsigned getval_359()
{
    return 3224948361U;
}

void setval_179(unsigned *p)
{
    *p = 3677933257U;
}

unsigned addval_430(unsigned x)
{
    return x + 3269495112U;
}

void setval_272(unsigned *p)
{
    *p = 3380920969U;
}

unsigned addval_495(unsigned x)
{
    return x + 3281179017U;
}

void setval_207(unsigned *p)
{
    *p = 2428668380U;
}

void setval_479(unsigned *p)
{
    *p = 3534013065U;
}

unsigned getval_299()
{
    return 3674784457U;
}

unsigned getval_205()
{
    return 3286276424U;
}

unsigned addval_252(unsigned x)
{
    return x + 3767093414U;
}

unsigned addval_122(unsigned x)
{
    return x + 3381973385U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
